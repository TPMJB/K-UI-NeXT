# Evolution 1/2 SCI Background PIO-pair candidate

Build **af401496961a**. Follow the numbered tests in [../TESTS.md](../TESTS.md)
and record results in [../RESULTS.csv](../RESULTS.csv). Keep this directory intact.

From this directory:

```sh
python3 personalize.py /run/media/apollonius/Dreamcast --profile KUI/vmu-test/p0005/retail-persistent-profile-0005.bin --game evolution1 --profile-runtime
```

Use only the admitted Evolution 1 and Evolution 2 images. For Evolution 2 use --game evolution2. Set SCI, Background On, Normal, Auto encoding, CD music Off and RAM patches Off.

Leave physical A2 empty. Keep --profile-runtime installed for all runs. Long
play uses no capture gesture; make the separately required diagnostic run
afterward. See the top-level worksheet for the correct report-cycle heading.
