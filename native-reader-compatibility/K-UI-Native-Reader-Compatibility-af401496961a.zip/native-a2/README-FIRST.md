# Generic native SCI Standard / virtual-A2 candidate

Build **af401496961a**. Follow the numbered tests in [../TESTS.md](../TESTS.md)
and record results in [../RESULTS.csv](../RESULTS.csv). Keep this directory intact.

From this directory:

```sh
python3 personalize.py /run/media/apollonius/Dreamcast --profile KUI/vmu-test/p0005/retail-persistent-profile-0005.bin --profile-runtime
```

Omitting --game requests fresh SDK-family discovery. Set SCI, Background Off, Auto encoding, CD music Off and RAM patches Off. This module does not test the PIO-pair reader.

Leave physical A2 empty. Keep --profile-runtime installed for all runs. Long
play uses no capture gesture; make the separately required diagnostic run
afterward. See the top-level worksheet for the correct report-cycle heading.
