#include "kui/native_readahead.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
static unsigned rows,pages,words,seen[38];static int track;
void retail_display_restore(const struct retail_display_state *d){(void)d;if(pages)assert(rows<=16);++pages;rows=0;}
void retail_display_line(const char*s){assert(strlen(s)<=49);++rows;assert(rows<=16);}
void retail_display_values(const char*s,const uint32_t*v,unsigned n){assert(n<=5);retail_display_line(s);++rows;assert(rows<=16);if(track)for(unsigned i=0;i<n;i++){assert(v[i]>=1&&v[i]<=37);seen[v[i]]++;words++;}}
void retail_display_pause(uint32_t n){assert(n==240);assert(rows<=16);}
/* Eight label/value pairs fit the sixteen body rows. The immutable field
 * map keeps every raw word while sharing one formatter and argument buffer. */
static void reader_readahead_failure(const struct retail_display_state *display,
    const struct kui_native_ra_failure_snapshot *s,const char *heading) {
#define RA_FIELD(name) (offsetof(struct kui_native_ra_failure_snapshot,name)/4u)
    static const uint8_t field[37]={RA_FIELD(stage),RA_FIELD(result),RA_FIELD(event),
        RA_FIELD(flags),RA_FIELD(token),RA_FIELD(cursor_block),RA_FIELD(cache_base),
        RA_FIELD(cache_count),RA_FIELD(cache_end),RA_FIELD(operation_lba),RA_FIELD(loan_state),
        RA_FIELD(rx_flags),RA_FIELD(ready_lba[0]),RA_FIELD(ready_lba[1]),RA_FIELD(kept_lba),
        RA_FIELD(arrived),RA_FIELD(lost),RA_FIELD(stream_state),RA_FIELD(stream_position),
        RA_FIELD(pre.sar),RA_FIELD(pre.dar),RA_FIELD(pre.tcr),RA_FIELD(pre.chcr),RA_FIELD(pre.dmaor),
        RA_FIELD(post.sar),RA_FIELD(post.dar),RA_FIELD(post.tcr),RA_FIELD(post.chcr),RA_FIELD(post.dmaor),
        RA_FIELD(pre.sci),RA_FIELD(pre.pins),RA_FIELD(pre.tmu),RA_FIELD(post_stream_state),
        RA_FIELD(post_stream_position),RA_FIELD(post.sci),RA_FIELD(post.pins),RA_FIELD(post.tmu)};
#undef RA_FIELD
    static const uint8_t count[8]={5,5,5,4,5,5,5,3};
    static const char *const label[7]={"BLK BASE COUNT END OP","LOAN RX R0 R1 KEPT",
        "ARRIVED LOST PRE STATE POS","PRE SAR DAR TCR CHCR DMAOR",
        "POST SAR DAR TCR CHCR DMAOR","PRE SCI PINS TMU POST STATE POS","POST SCI PINS TMU"};
    uint32_t values[5];unsigned at=0u;
    retail_display_restore(display);
    for(unsigned row=0u;row<8u;row++) {
        for(unsigned col=0u;col<count[row];col++,at++)
            memcpy(&values[col],(const uint8_t *)s+4u*field[at],4u);
        retail_display_values(row?label[row-1u]:heading,values,count[row]);
    }
    retail_display_pause(240u);
}
static void reader_readahead_diagnostics(const struct retail_display_state *display,
    const struct kui_native_ra_diagnostics *d) {
    retail_display_restore(display);
    retail_display_line("READ AHEAD EXIT REASONS");
    uint32_t stages[7]={d->failures,0,0,0,0,0,0};
    for(unsigned stage=1u;stage<KUI_NATIVE_RA_STAGE_COUNT;stage++)
        for(unsigned result=0u;result<KUI_NATIVE_RA_RESULT_COUNT;result++)
            stages[stage]+=d->stage_result[stage][result];
    retail_display_values("FAIL POLL TAKE APPEND FETCH",stages,5u);
    retail_display_values("RESUME STOP FIRST ST LAST ST",(uint32_t[4]){
        stages[5],stages[6],d->first.stage,d->last.stage},4u);
    const uint32_t *n=d->skipped;
    retail_display_values("SKIP QUIET ABORT SEED LOAN ACTIVE",n,5u);
    retail_display_values("SKIP PEND FAIL OPEN PORT BUSY",n+5u,5u);
    retail_display_values("SKIP DMA POS DEFER OWNED",n+10u,4u);
    retail_display_pause(240u);
    if(!d->failures)return;
    bool same=!memcmp(&d->first,&d->last,sizeof(d->first));
    reader_readahead_failure(display,&d->first,same?
        "BOTH ST RES EVT FL TOK":
        "FIRST ST RES EVT FL TOK");
    if(!same)reader_readahead_failure(display,&d->last,
        "LAST ST RES EVT FL TOK");
}
int main(void){struct retail_display_state display={0};struct kui_native_ra_failure_snapshot s;
 for(unsigned i=0;i<37;i++){uint32_t v=i+1;memcpy((char*)&s+i*4,&v,4);}track=1;
 reader_readahead_failure(&display,&s,"FIRST FAILURE STAGE RESULT EVENT FLAGS TOKEN");assert(rows==16&&words==37);for(unsigned i=1;i<=37;i++)assert(seen[i]==1);track=0;
 struct kui_native_ra_diagnostics d={0};pages=0;reader_readahead_diagnostics(&display,&d);assert(pages==1);
 d.failures=1;d.first=s;d.last=s;pages=0;reader_readahead_diagnostics(&display,&d);assert(pages==2);
 d.failures=2;d.last.event++;pages=0;reader_readahead_diagnostics(&display,&d);assert(pages==3);
 puts("Actual diagnostic display helpers: all37words exactlyonce,16-rowviewport,0/1/multiplefailurepages passed");return 0;}
