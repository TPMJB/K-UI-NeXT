# REVIEW PACKAGE: NOT APPROVED FOR ORDER

Artwork for inspection only (for example in a Gerber viewer or the fabricator's online preview). It is plotted the same way as the release exporter, but the owner reviews in `manufacturing/review-evidence.json` are not accepted, so `prepare_jlcpcb_release.py --export` still refuses to build an order package. Order only from that exporter's output.

Native check results for each board are in `summary.json` and each `checks/` folder.
