# Native Background fallback limit — 74958b387827

This candidate keeps background DMA and limits synchronous PIO fallback to
one SD data block per native loader call or reader interrupt. A reproduced
64-sector request previously read all 256 SD blocks in one masked visit.
This change is intended to reduce gameplay stalls while retaining the
background DMA path that played your Evolution 2 FMV smoothly.

## Install

Use the same prepared profile as your last successful test. For your p0005
profile, from this extracted folder run:

```sh
python3 personalize.py /run/media/apollonius/Dreamcast --profile KUI/vmu-test/p0005/retail-persistent-profile-0005.bin --game evolution2
```

Select a different explicit profile if that is the card you have been using.
Keep Background On (X/20 is the normal background setting); keep physical A2
empty. A1 remains available for a physical card. There is no new hybrid toggle:
this package contains the bounded Background reader. Replacing the module is
necessary; changing a menu toggle alone does not install it.

## Compare

Use the same game image and settings as the previous test. Check the opening
FMV, the same gameplay area, and save/load after reboot. Host regression,
byte-integrity, DMA-sequence, ownership and linked memory checks passed.
Console frame timing remains unverified. Movies that themselves use PIO
fallback could trade throughput for the shorter work slices; existing token
and command timeouts are unchanged.

The separate Full ZIP preserves exact source commit `74958b3878279fc916199a7cd330f7f17b036138`, its
history, the previous 9fa65fc1cae0 comparison package, and the recovered EDF
module/source reference. EDF's original regular-loading FMV difference remains
unresolved; it has not been relabeled as a Background result.

No card image, user save or retail game executable is included.
